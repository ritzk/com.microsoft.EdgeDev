#define anytostr offtostr
#define inttype off_t
#include "anytostr.c"
